import { useState } from "react";
import axios from "axios";

function Login({ onLogin, onRegister }) {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [loading, setLoading] = useState(false);

    const handleLogin = async (e) => {
        e.preventDefault();

        try {
            setLoading(true);

            const response = await axios.post(
                "http://localhost:5000/api/auth/login",
                {
                    email,
                    password
                }
            );

            console.log("Login response:", response.data);

            // Save JWT token
            localStorage.setItem(
                "token",
                response.data.token
            );

            alert("Login successful");

            // Tell App.jsx login was successful
            onLogin();

        } catch (error) {
            console.error("Login error:", error);

            alert(
                error.response?.data?.message ||
                "Login failed"
            );

        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="login-container">

            <form
                className="login-form"
                onSubmit={handleLogin}
            >

                <h2>Expense Tracker</h2>

                <h3>Login</h3>

                <input
                    type="email"
                    placeholder="Enter email"
                    value={email}
                    onChange={(e) =>
                        setEmail(e.target.value)
                    }
                    required
                />

                <input
                    type="password"
                    placeholder="Enter password"
                    value={password}
                    onChange={(e) =>
                        setPassword(e.target.value)
                    }
                    required
                />

                <button
                    type="submit"
                    disabled={loading}
                >
                    {loading
                        ? "Logging in..."
                        : "Login"}
                </button>

                <p>
                    Don't have an account?{" "}
                    <button
                        type="button"
                        onClick={onRegister}
                    >
                        Register
                    </button>
                </p>

            </form>

        </div>
    );
}

export default Login;