import { useEffect, useState } from "react";

import ExpenseForm from "../components/expenseForm";
import ExpenseList from "../components/expenseList";

import {
    getExpenses,
    createExpense,
    deleteExpense,
} from "../services/expenseApi";

function Home() {
    const [expenses, setExpenses] = useState([]);
    const [loading, setLoading] = useState(true);

    // Get expenses
    const loadExpenses = async () => {
        try {
            const data = await getExpenses();

            setExpenses(data);
        } catch (error) {
            console.error("Error fetching expenses:", error);

            console.log("Status:", error.response?.status);
            console.log("Backend response:", error.response?.data);

            alert(
                error.response?.data?.message ||
                "Failed to load expenses"
            );
        }
    };

    useEffect(() => {
        loadExpenses();
    }, []);

    // Add expense
    const handleAddExpense = async (expense) => {
        try {
            const newExpense = await createExpense(expense);

            setExpenses((prev) => [...prev, newExpense]);
        } catch (error) {
            console.error("Error adding expense:", error);
            alert("Failed to add expense");
        }
    };

    // Delete expense
    const handleDeleteExpense = async (id) => {
        try {
            await deleteExpense(id);

            setExpenses((prev) =>
                prev.filter((expense) => expense._id !== id)
            );
        } catch (error) {
            console.error("Error deleting expense:", error);
            alert("Failed to delete expense");
        }
    };

    // Total expense
    const totalExpense = expenses.reduce(
        (total, expense) => total + Number(expense.amount),
        0
    );

    return (
        <div className="container">
            <h1>Expense Tracker</h1>

            <div className="summary">
                <h2>Total Expense</h2>
                <h1>₹{totalExpense}</h1>
            </div>

            <ExpenseForm onAddExpense={handleAddExpense} />

            <h2>All Expenses</h2>

            {loading ? (
                <p>Loading expenses...</p>
            ) : (
                <ExpenseList
                    expenses={expenses}
                    onDelete={handleDeleteExpense}
                />
            )}
        </div>
    );
}

export default Home;