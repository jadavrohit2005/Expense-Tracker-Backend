import { useState } from "react";
import axios from "axios";

function Register() {
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [loading, setLoading] = useState(false);

    const handleRegister = async (e) => {
        e.preventDefault();

        try {
            setLoading(true);

            const response = await axios.post(
                "http://localhost:5000/api/auth/register",
                {
                    name,
                    email,
                    password
                }
            );

            console.log("Register response:", response.data);

            // Save token returned by backend
            localStorage.setItem(
                "token",
                response.data.token
            );

            alert("Registration successful");

            window.location.href = "/";

        } catch (error) {
            console.error("Register error:", error);

            alert(
                error.response?.data?.message ||
                "Registration failed"
            );

        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="login-container">
            <form
                className="login-form"
                onSubmit={handleRegister}
            >
                <h2>Expense Tracker</h2>

                <h3>Create Account</h3>

                <input
                    type="text"
                    placeholder="Enter name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                />

                <input
                    type="email"
                    placeholder="Enter email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                />

                <input
                    type="password"
                    placeholder="Enter password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                />

                <button
                    type="submit"
                    disabled={loading}
                >
                    {loading ? "Creating..." : "Register"}
                </button>
            </form>
        </div>
    );
}

export default Register;