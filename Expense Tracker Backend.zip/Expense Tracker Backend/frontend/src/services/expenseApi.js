import axios from "axios";

const API = axios.create({
    baseURL: "http://localhost:5000/api"
});


// Get all expenses
export const getExpenses = async () => {
    const response = await API.get("/expenses");
    return response.data;
};


// Get summary
export const getSummary = async () => {
    const response = await API.get("/expenses/summary");
    return response.data;
};


// Create expense
export const createExpense = async (expense) => {
    const response = await API.post(
        "/expenses",
        expense
    );

    return response.data;
};


// Update expense
export const updateExpense = async (id, expense) => {
    const response = await API.put(
        `/expenses/${id}`,
        expense
    );

    return response.data;
};


// Delete expense
export const deleteExpense = async (id) => {
    const response = await API.delete(
        `/expenses/${id}`
    );

    return response.data;
};