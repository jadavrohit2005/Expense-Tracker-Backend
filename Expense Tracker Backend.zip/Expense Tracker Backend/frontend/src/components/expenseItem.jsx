function ExpenseItem({ expense, onDelete }) {
  return (
    <div className="expense-item">
      <div>
        <h3>{expense.title}</h3>

        <p>
          Category: <strong>{expense.category}</strong>
        </p>

        <p>Date: {expense.date}</p>
      </div>

      <div>
        <h3>₹{expense.amount}</h3>

        <button
          className="delete-btn"
          onClick={() => onDelete(expense._id)}
        >
          Delete
        </button>
      </div>
    </div>
  );
}

export default ExpenseItem;