function Navbar() {
  return (
    <nav className="navbar">
      <h2>Expense Tracker</h2>

      <div>
        <a href="/">Home</a>
        <a href="/">Expenses</a>
      </div>
    </nav>
  );
}

export default Navbar;