

const notFound = (req, res, next) => {
    res.status(404);

    next(new Error(`route not found: ${req.originalUrl}`))
}

    const errorHandel = (err, req, res, next) => {
        const statusCode = res.statusCode === 200 ? 500 : res.statusCode;

        res.statusCode(statusCode).json({
            message: err.message,
            stack: process.env.NODE_ENV === "production" ? null : err.stack
        })
    }


export default {
    notFound,
    errorHandel
}