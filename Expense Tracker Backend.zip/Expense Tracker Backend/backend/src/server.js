import dotenv from "dotenv";
import dns from "dns";
import app from "./app.js";
import connectDB from "./config/db.js";

dotenv.config();

// Use Google DNS for MongoDB Atlas SRV connection
dns.setServers(["8.8.8.8", "8.8.4.4"]);

const PORT = process.env.PORT || 5000;

const startServer = async () => {
    try {
        // Connect MongoDB first
        await connectDB();

        // Start Express server
        app.listen(PORT, () => {
            console.log(`✅ Server is running on port ${PORT}`);
            console.log(`🚀 API: http://localhost:${PORT}`);
        });

    } catch (error) {
        console.error("❌ MongoDB connection failed:");
        console.error(error.message);

        process.exit(1);
    }
};

startServer();