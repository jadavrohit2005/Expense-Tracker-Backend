import mongoose from "mongoose";


const expenseSchema = new mongoose.Schema(
    {
        user: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: true
        },
        title: {
            type: String,
            trim: true,
            required: true
        },
        amount: {
            type: Number,
            min: 0,
            required: true
        },
        category: {
            type: String,
            required: true,
            enum: [
                "food",
                "transport",
                "shopping",
                "bills",
                "entertainment",
                "health",
                "education",
                "other",
            ]
        },
        description: {
            type: String,
            trim: true,
            default: " "

        },
        date: {

            type: Date,
            default: Date.now,
            required: true
        },
    },
    {
        timestamps: true
    }
);
const Expense = mongoose.model("Expense", expenseSchema);

export { Expense };
