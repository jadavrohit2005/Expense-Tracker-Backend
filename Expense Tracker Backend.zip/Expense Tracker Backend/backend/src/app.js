import express from "express";
import cors from "cors";

import expenseRoutes from "./routes/expenseRoutes.js";

const app = express();

app.use(
    cors({
        origin: "http://localhost:5173"
    })
);

app.use(express.json());


// Test route
app.get("/", (req, res) => {
    res.json({
        message: "Expense Tracker API is running"
    });
});


// Expense routes
app.use("/api/expenses", expenseRoutes);


// 404
app.use((req, res) => {
    res.status(404).json({
        message: "Route not found"
    });
});

export default app;