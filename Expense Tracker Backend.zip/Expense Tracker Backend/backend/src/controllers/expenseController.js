import { Expense } from "../models/Expense.js";


// ==========================================
// CREATE EXPENSE
// ==========================================

const createExpense = async (req, res) => {
    try {
        const {
            title,
            amount,
            category,
            description,
            date
        } = req.body;

        if (!title || amount === undefined || !category) {
            return res.status(400).json({
                message: "title, amount and category are required"
            });
        }

        if (Number(amount) <= 0) {
            return res.status(400).json({
                message: "amount must be greater than zero"
            });
        }

        const expense = await Expense.create({
            title,
            amount: Number(amount),
            category,
            description,
            date: date || new Date()
        });

        res.status(201).json(expense);

    } catch (error) {
        console.error("Create Expense Error:", error);

        res.status(500).json({
            message: "Failed to create expense"
        });
    }
};


// ==========================================
// GET ALL EXPENSES
// ==========================================

const getExpenses = async (req, res) => {
    try {
        const {
            category,
            startDate,
            endDate,
            search
        } = req.query;

        const query = {};

        if (category && category !== "all") {
            query.category = category;
        }

        if (startDate || endDate) {
            query.date = {};

            if (startDate) {
                query.date.$gte = new Date(startDate);
            }

            if (endDate) {
                const end = new Date(endDate);
                end.setHours(23, 59, 59, 999);

                query.date.$lte = end;
            }
        }

        if (search) {
            query.$or = [
                {
                    title: {
                        $regex: search,
                        $options: "i"
                    }
                },
                {
                    description: {
                        $regex: search,
                        $options: "i"
                    }
                }
            ];
        }

        const expenses = await Expense.find(query).sort({
            date: -1,
            createdAt: -1
        });

        res.status(200).json(expenses);

    } catch (error) {
        console.error("Get Expenses Error:", error);

        res.status(500).json({
            message: "Failed to fetch expenses"
        });
    }
};


// ==========================================
// GET SINGLE EXPENSE
// ==========================================

const getExpense = async (req, res) => {
    try {
        const expense = await Expense.findById(req.params.id);

        if (!expense) {
            return res.status(404).json({
                message: "Expense not found"
            });
        }

        res.status(200).json(expense);

    } catch (error) {
        console.error("Get Expense Error:", error);

        res.status(500).json({
            message: "Failed to fetch expense"
        });
    }
};


// ==========================================
// UPDATE EXPENSE
// ==========================================

const updateExpense = async (req, res) => {
    try {
        const expense = await Expense.findById(req.params.id);

        if (!expense) {
            return res.status(404).json({
                message: "Expense not found"
            });
        }

        const {
            title,
            amount,
            category,
            description,
            date
        } = req.body;

        if (amount !== undefined && Number(amount) <= 0) {
            return res.status(400).json({
                message: "Amount must be greater than zero"
            });
        }

        expense.title = title ?? expense.title;

        expense.amount =
            amount !== undefined
                ? Number(amount)
                : expense.amount;

        expense.category = category ?? expense.category;

        expense.description =
            description ?? expense.description;

        expense.date = date ?? expense.date;

        await expense.save();

        res.status(200).json(expense);

    } catch (error) {
        console.error("Update Expense Error:", error);

        res.status(500).json({
            message: "Failed to update expense"
        });
    }
};


// ==========================================
// DELETE EXPENSE
// ==========================================

const deleteExpense = async (req, res) => {
    try {
        const expense = await Expense.findByIdAndDelete(
            req.params.id
        );

        if (!expense) {
            return res.status(404).json({
                message: "Expense not found"
            });
        }

        res.status(200).json({
            message: "Expense deleted successfully"
        });

    } catch (error) {
        console.error("Delete Expense Error:", error);

        res.status(500).json({
            message: "Failed to delete expense"
        });
    }
};


// ==========================================
// SUMMARY
// ==========================================

const getSummary = async (req, res) => {
    try {
        const expenses = await Expense.find();

        const totalExpense = expenses.reduce(
            (total, expense) =>
                total + Number(expense.amount),
            0
        );

        const categoryTotals = {};

        expenses.forEach((expense) => {
            if (!categoryTotals[expense.category]) {
                categoryTotals[expense.category] = 0;
            }

            categoryTotals[expense.category] +=
                Number(expense.amount);
        });

        res.status(200).json({
            totalExpense,
            expenseCount: expenses.length,
            categoryTotals
        });

    } catch (error) {
        console.error("Summary Error:", error);

        res.status(500).json({
            message: "Failed to fetch summary"
        });
    }
};


export {
    getExpenses,
    getExpense,
    createExpense,
    updateExpense,
    deleteExpense,
    getSummary
};